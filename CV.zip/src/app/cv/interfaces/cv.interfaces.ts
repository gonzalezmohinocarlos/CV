export interface Curso{    
        "titulo": string,
        "descripcion": string   
}

